package inheritanceExample;

public class Cat extends Animal {
	
	private int lives = 9;
	
	public void meow() {
		System.out.println("Meow!");
	}
	
	public void beAloof() {
		System.out.println("Cat ignores you.");
	}
}
