package inheritanceExample;

public class Dog extends Animal {
	
	private String breed;
	
	public void bark() {
		System.out.println("Woof!");
	}
	
	public void chaseCar() {
		System.out.println("Dog runs frantically...");
		bark();
		bark();
		System.out.println("Dog is still running...");
		bark();
		System.out.println("Dog gets tired and goes home.");
	}
}
