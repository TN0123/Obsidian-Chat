package inheritanceExample;

public class Bird extends Animal {
	
	public void fly() {
		System.out.println("Bird soars through the air.");
	}
	
	@Override
	public void eat() {
		System.out.println("Bird pecks at food with beak.");
	}
}
