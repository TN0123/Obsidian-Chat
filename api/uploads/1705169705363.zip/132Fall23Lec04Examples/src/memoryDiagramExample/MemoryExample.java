package memoryDiagramExample;


public class MemoryExample {
		
	private static void f(int x, Dog dog) {
		Dog.MAX_WEIGHT = 400;
		x = 17;
		dog.setName("Liz");
	}
	
	public static void main(String[] args) {
		int x = 7;
		Dog dog = new Dog("Steve", 55);    // Don't forget static variable!
		Dog.MAX_WEIGHT = 100;
		
		f(x, dog);   // Will x change?  Will dog change?
		
		System.out.println("x is " + x);
		System.out.println("dog's name is " + dog.getName());
		System.out.println("Max is now: " + Dog.MAX_WEIGHT);
	}
}
