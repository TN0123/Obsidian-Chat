package memoryDiagramExample;

public class Dog {
	
	public static int MAX_WEIGHT = 200;
	
	private String name;
	private int size;
	
	public Dog(String name, int size){
		this.name = name;
		this.size = size;
	}
	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if ( !(other instanceof Dog) ) {
			return false;
		}
		Dog dog = (Dog)other;
		return (dog.name.equals(name) && dog.size == size);
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String toString() {
		return name + ": " + size + " lbs.";
	}

}
