package privacyLeakExample;

public class Driver01 {

	public static void main(String[] args) {
		MarylandLicensePlate plate = new MarylandLicensePlate();
		System.out.println(plate);
		plate.symbols = "THIS IS FAWZI'S AWESOME CAR".toCharArray();
		System.out.println(plate);
	}
}
