package privacyLeakExample;

import java.util.Arrays;
import java.util.Random;

/* Assume MD license plates must follow this pattern:
 * 
 * #XX####   (Digit, Letter, Letter, Digit, Digit, Digit, Digit)
 * 
 * For example:  7AX9175   is a legit plate
 * 
 * BIG CONCEPT:  We want to enforce the policy that it is IMPOSSIBLE
 * for a license plate to ever violate this pattern!
 * 
 */

public class MarylandLicensePlate {

	public char[] symbols = new char[7];   // THIS SHOULD BE PRIVATE!!!
	
	private static Random random = new Random();
	
	public MarylandLicensePlate() {
		symbols[0] = getRandomDigit();
		symbols[1] = getRandomLetter();
		symbols[2] = getRandomLetter();
		for (int i = 3; i <= 6; i++) {
			symbols[i] = getRandomDigit();
		}
	}
	
	public MarylandLicensePlate(char[] symbols) {
		if (!Character.isDigit(symbols[0]) || !Character.isLetter(symbols[1]) ||
			!Character.isLetter(symbols[2]) || !Character.isDigit(symbols[3]) ||
			!Character.isDigit(symbols[4]) || !Character.isDigit(symbols[5]) ||
			!Character.isDigit(symbols[5])) {
			throw new IllegalArgumentException("Symbols are incorrect.");
		}
		this.symbols = symbols;  // PRIVACY LEAK!!  We should make a copy of the array.
	}
	
	public char[] getSymbols() {
		return  symbols;  // PRIVACY LEAK!!  We should return a copy of the array.
	}
	
	/* Returns random digit from 0 to 9 */
	private static char getRandomDigit() {
		return (char)(random.nextInt(10) + '0');
	}
	
	/* Returns random letter from A to Z */
	private static char getRandomLetter() {
		return (char)(random.nextInt(26) + 'A');
	}
	
	public String toString() {
		return String.valueOf(symbols);
	}
	
}
