package privacyLeakExample;

public class Driver02 {

	public static void main(String[] args) {
		MarylandLicensePlate plate = new MarylandLicensePlate();
		System.out.println(plate);
		char[] localCopy = plate.getSymbols();
		for (int i = 0; i < localCopy.length; i++) {
			localCopy[i] = '@';
		}
		System.out.println(plate);
	}

}
