package privacyLeakExample;

public class Driver03 {

	public static void main(String[] args) {
		char[] symbols = "5XY1257".toCharArray();
		MarylandLicensePlate plate = new MarylandLicensePlate(symbols);
		System.out.println(plate);
		for (int i = 0; i < 7; i++) {
			symbols[i] = '@';
		}
		
		System.out.println(plate);
	}

}
